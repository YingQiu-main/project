import app from './app';
import { initDB } from './models';
import dotenv from 'dotenv';

// ==================================================================
// 1. 环境配置加载
// ==================================================================
// 加载 .env 文件中的环境变量
// 在项目根目录下创建 .env 文件，可以配置 PORT, JWT_SECRET 等敏感信息
dotenv.config();

// 设置服务器监听端口，默认为 3000
const PORT = process.env.PORT || 3000;

// ==================================================================
// 2. 服务器启动流程
// ==================================================================
const startServer = async () => {
  try {
    console.log('Starting server...');

    // 第一步：初始化数据库
    // 连接 SQLite 数据库，并根据 Model 定义自动创建/更新数据表
    await initDB();
    console.log('Database initialized successfully.');
    
    // 第二步：启动 HTTP 服务器
    // app.listen 开启端口监听，开始接收 HTTP 请求
    app.listen(PORT, () => {
      console.log(`
      ################################################
      🛡️  Server listening on port: ${PORT} 🛡️
      http://localhost:${PORT}
      ################################################
      `);
    });

  } catch (error) {
    // 如果启动过程中发生错误 (如数据库连接失败)，打印错误并退出进程
    console.error('Failed to start server:', error);
    process.exit(1); // 非 0 状态码表示异常退出
  }
};

// 执行启动函数
startServer();
