import { Sequelize } from 'sequelize';
import path from 'path';

// 使用 Sequelize 连接 SQLite 数据库
// Sequelize 是一个 ORM (对象关系映射) 库，可以让我们用 JavaScript 对象的方式操作数据库
const sequelize = new Sequelize({
  dialect: 'sqlite',
  // 数据库文件存储位置
  storage: path.join(__dirname, '../../database.sqlite'),
  // 禁用日志输出，避免控制台太乱（开发时可以开启）
  logging: false,
});

export default sequelize;

