import sequelize from '../config/database';
import User from './User';
import Word from './Word';
import Sentence from './Sentence';
import Article from './Article';
import StudyRecord from './StudyRecord';
import Favorite from './Favorite';

// 定义模型关联
// User has many StudyRecords
User.hasMany(StudyRecord, { foreignKey: 'userId' });
StudyRecord.belongsTo(User, { foreignKey: 'userId' });

// User has many Favorites
User.hasMany(Favorite, { foreignKey: 'userId' });
Favorite.belongsTo(User, { foreignKey: 'userId' });

// 导出初始化数据库的方法
const initDB = async () => {
  try {
    // sync({ force: true }) 会删除原有表重新创建，开发阶段慎用
    // sync({ alter: true }) 会尝试修改表结构以匹配模型
    await sequelize.sync({ alter: true }); 
    console.log('Database synced successfully.');
  } catch (error) {
    console.error('Unable to sync database:', error);
  }
};

export { 
  sequelize, 
  initDB, 
  User, 
  Word, 
  Sentence, 
  Article, 
  StudyRecord, 
  Favorite 
};

